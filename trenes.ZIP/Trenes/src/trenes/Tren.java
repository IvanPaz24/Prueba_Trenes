/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trenes;

import java.util.ArrayList;

/**
 *
 * @author ivan_
 */
public abstract class Tren {
    protected int capacidadMaximaPasajero;
    protected String destino;
    protected boolean motorEncendido;
    public int cantidadActual = 0;

    public Tren(int capacidadMaximaPasajero, String destino) {
        this.capacidadMaximaPasajero = capacidadMaximaPasajero;
        this.destino = destino;
    }

    public int getCapacidad() {
        return capacidadMaximaPasajero;
    }

    public String getDestino() {
        return "\n" + destino.toUpperCase();
    }

    public boolean getMotor() {
        return motorEncendido;
    }

    public void setMotor(boolean motorEncendido) {
        this.motorEncendido = motorEncendido;
    }
    
    public abstract ArrayList<Pasajero> getPasajero();
    
    public static boolean sonIguales(Pasajero p2, Tren t){
        boolean flag = false;
        
        
//        int i = 0;
//        while (i < t.getPasajero().size() && !(t.getPasajero().get(i).sonIguales(p2, t.getPasajero().get(i)))) {            
 //           i++;
 //       }
                
//       return p2.sonIguales(p2, t.getPasajero().get(i));
        for ( Pasajero p: t.getPasajero()){
            if (p.sonIguales(p, p2)) {
                flag = true;
            }
        }
        
        return flag;
    }
            
    
    
    public void agregar(Pasajero p){
        //int cantidadActual;
        
        if (p == null) {
            throw new NullPointerException();
        }
        
        if (getCapacidad() > cantidadActual && !(sonIguales(p, this))){
            getPasajero().add(p);
            cantidadActual++;
        }
        else
        {
            System.out.println("\nPasajero existente o cantidad superada");
        }
        
    }

    @Override
    public String toString() {
        return "\ncapacidadMaximaPasajero=" + capacidadMaximaPasajero + ", destino=" + destino.toUpperCase() + ", motorEncendido=" + motorEncendido + '}';
    }
}
