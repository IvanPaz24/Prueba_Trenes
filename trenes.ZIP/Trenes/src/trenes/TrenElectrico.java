/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trenes;

import java.util.ArrayList;

/**
 *
 * @author ivan_
 */
public class TrenElectrico extends Tren{
    protected ArrayList<Pasajero> pasajeros; 

    public TrenElectrico(int capacidadMaximaPasajero, String destino) {
        super(capacidadMaximaPasajero, destino);
        this.pasajeros = new ArrayList<>();
    }

    @Override
    public ArrayList<Pasajero> getPasajero() {
        return pasajeros;
    }

    @Override
    public String toString() {
        return super.toString() + "TrenElectrico{" + "pasajeros=" + pasajeros + '}';
    }
}
