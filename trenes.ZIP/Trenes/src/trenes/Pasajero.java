/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trenes;

import java.util.Objects;

/**
 *
 * @author ivan_
 */
public class Pasajero {
    private String apellido;
    private String nombre;
    private Rangos rango;
    
    public Pasajero(){
        this.apellido = "SIN APELLIDO";
        this.nombre = "SIN NOMBRE";
        this.rango = Rangos.CLIENTE;
    }
    
    public Pasajero(String apellido){
        this.apellido = apellido;
        this.nombre = "SIN NOMBRE";
        this.rango = Rangos.CLIENTE;
    }
    
     public Pasajero(String apellido, String nombre){
        this.apellido = apellido;
        this.nombre = nombre;
        this.rango = Rangos.CLIENTE;
    }
     
      public Pasajero(String apellido, String nombre, Rangos rango){
        this.apellido = apellido;
        this.nombre = nombre;
        this.rango = rango;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public Rangos getRango() {
        return rango;
    }
    
    public static boolean sonIguales(Pasajero a, Pasajero b){
        
        if (a == null || b == null) {
            throw new NullPointerException();
        }
        
        boolean flag = false;
        
        if (a.getApellido().equals(b.getApellido()) && a.getNombre().equals(b.getNombre()) && 
            a.getRango() == b.getRango()){
            flag = true;
        }
        
        return flag;
    }

    @Override
    public String toString() {
        return "\nPasajero{" + "apellido=" + apellido + ", nombre=" + nombre + ", rango=" + rango + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
//        if (getClass() != obj.getClass()) {
//            return false;
//        }
        Pasajero other = (Pasajero) obj;
        
        //if (!Objects.equals(this.apellido, other.apellido)) {
         //   return false;
        //}
        
//        if () {
//            
//        }
        
        return nombre.equals(other.getNombre()) && apellido.equals(other.getApellido());
        //return Objects.equals(this.nombre, other.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.toString().hashCode());
    }
}
